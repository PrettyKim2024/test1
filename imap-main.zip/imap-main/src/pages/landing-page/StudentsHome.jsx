import { LampDemo } from '../../components/ui/lamp';

function StudentsHome() {
  return (
    <div className='py-20'>
      <LampDemo />   
    </div>
  )
}

export default StudentsHome
